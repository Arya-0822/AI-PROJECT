# computer_career_app.py
import pandas as pd
import streamlit as st
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
import random
import os

# -----------------------------
# Step 1: Generate dataset
# -----------------------------

# List of computer-related skills
skills_list = [
    "python", "java", "c++", "html", "css", "javascript", "react", "angular",
    "nodejs", "sql", "mongodb", "excel", "powerbi", "machine learning",
    "deep learning", "data analysis", "data visualization", "cloud computing",
    "aws", "azure", "gcp", "linux", "git", "docker", "kubernetes",
    "cybersecurity", "networking", "ai", "nlp", "tensorflow", "pytorch",
    "opencv", "big data", "hadoop", "spark", "etl", "jira", "agile", "scrum",
    "robotic process automation", "qa testing", "selenium", "rest api", "graphql",
    "devops", "unity", "unreal engine"
]

# List of computer-related careers/jobs
jobs_list = [
    "Software Engineer", "Data Scientist", "Web Developer", "Frontend Developer",
    "Backend Developer", "Full Stack Developer", "Database Administrator",
    "Machine Learning Engineer", "AI Engineer", "Cloud Engineer",
    "DevOps Engineer", "Network Engineer", "Cybersecurity Analyst",
    "QA Engineer", "Game Developer", "Data Analyst", "Business Intelligence Analyst",
    "Systems Administrator", "Robotics Engineer", "Computer Vision Engineer",
    "NLP Engineer", "Big Data Engineer", "ETL Developer"
]

# Generate 1000 random rows
dataset = []
for _ in range(1000):
    num_skills = random.randint(2, 6)  # each person has 2-6 skills
    skills = random.sample(skills_list, num_skills)
    
    # Assign job based on some skill logic (simple mapping)
    if any(skill in ["python", "java", "c++", "react", "angular", "nodejs"] for skill in skills):
        job = random.choice(["Software Engineer", "Web Developer", "Full Stack Developer"])
    elif any(skill in ["machine learning", "deep learning", "tensorflow", "pytorch", "ai", "nlp"] for skill in skills):
        job = random.choice(["Data Scientist", "Machine Learning Engineer", "AI Engineer", "Computer Vision Engineer", "NLP Engineer"])
    elif any(skill in ["sql", "mongodb", "excel", "powerbi", "hadoop", "spark", "big data", "etl"] for skill in skills):
        job = random.choice(["Data Analyst", "Business Intelligence Analyst", "Big Data Engineer", "ETL Developer"])
    elif any(skill in ["aws", "azure", "gcp", "docker", "kubernetes", "devops"] for skill in skills):
        job = random.choice(["Cloud Engineer", "DevOps Engineer"])
    elif any(skill in ["linux", "networking", "cybersecurity", "qa testing", "selenium"] for skill in skills):
        job = random.choice(["Network Engineer", "Cybersecurity Analyst", "QA Engineer", "Systems Administrator"])
    elif any(skill in ["unity", "unreal engine", "robotic process automation"] for skill in skills):
        job = random.choice(["Game Developer", "Robotics Engineer"])
    else:
        job = random.choice(jobs_list)
    
    dataset.append({"skills": " ".join(skills), "career": job})

# Create DataFrame
df = pd.DataFrame(dataset)

# Save dataset
csv_path = "computer_career_1000.csv"
df.to_csv(csv_path, index=False)

# -----------------------------
# Step 2: Train model
# -----------------------------

X = df['skills'].astype(str).str.lower()
y = df['career']

# Vectorize
vectorizer = CountVectorizer(max_features=1000)
X_vec = vectorizer.fit_transform(X)

# Train Naive Bayes
model = MultinomialNB()
model.fit(X_vec, y)

# -----------------------------
# Step 3: Streamlit UI
# -----------------------------
st.title("🎯 AI Career Recommendation System")

st.write("This app recommends computer-related careers based on your skills.")

skills_input = st.text_input("Enter your skills (example: python sql machine learning)")

if st.button("Recommend"):
    if skills_input.strip() == "":
        st.warning("Please enter some skills to get a recommendation.")
    else:
        user_vec = vectorizer.transform([skills_input.lower()])
        prediction = model.predict(user_vec)
        st.success(f"Recommended Career: {prediction[0]}")

st.write("You can experiment with skills like: python, java, machine learning, sql, docker, react, tensorflow, aws")