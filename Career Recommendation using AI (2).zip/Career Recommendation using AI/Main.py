import pandas as pd
import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
import random

st.set_page_config(page_title="AI Career Navigator", page_icon="🚀", layout="centered")

# -----------------------------
# Step 1: Generate dataset
# -----------------------------

skills_list = [
    "python", "java", "c++", "html", "css", "javascript", "react", "angular",
    "nodejs", "sql", "mongodb", "excel", "powerbi", "machine learning",
    "deep learning", "data analysis", "data visualization", "cloud computing",
    "aws", "azure", "gcp", "linux", "git", "docker", "kubernetes",
    "cybersecurity", "networking", "ai", "nlp", "tensorflow", "pytorch",
    "opencv", "big data", "hadoop", "spark", "etl", "jira", "agile", "scrum",
    "robotic process automation", "qa testing", "selenium", "rest api", "graphql",
    "devops", "unity", "unreal engine"
]

jobs_list = [
    "Software Engineer", "Data Scientist", "Web Developer", "Frontend Developer",
    "Backend Developer", "Full Stack Developer", "Database Administrator",
    "Machine Learning Engineer", "AI Engineer", "Cloud Engineer",
    "DevOps Engineer", "Network Engineer", "Cybersecurity Analyst",
    "QA Engineer", "Game Developer", "Data Analyst", "Business Intelligence Analyst",
    "Systems Administrator", "Robotics Engineer", "Computer Vision Engineer",
    "NLP Engineer", "Big Data Engineer", "ETL Developer"
]

dataset = []
for _ in range(1500):  # more data = better learning
    skills = random.sample(skills_list, random.randint(2, 6))

    if any(s in ["python", "java", "c++", "react", "angular", "nodejs"] for s in skills):
        job = random.choice(["Software Engineer", "Web Developer", "Full Stack Developer"])
    elif any(s in ["machine learning", "deep learning", "tensorflow", "pytorch", "ai", "nlp"] for s in skills):
        job = random.choice(["Data Scientist", "Machine Learning Engineer", "AI Engineer"])
    elif any(s in ["sql", "mongodb", "excel", "powerbi", "hadoop", "spark"] for s in skills):
        job = random.choice(["Data Analyst", "Business Intelligence Analyst"])
    elif any(s in ["aws", "azure", "docker", "kubernetes"] for s in skills):
        job = random.choice(["Cloud Engineer", "DevOps Engineer"])
    else:
        job = random.choice(jobs_list)

    dataset.append({"skills": " ".join(skills), "career": job})

df = pd.DataFrame(dataset)

# -----------------------------
# Step 2: Train Model (Advanced)
# -----------------------------

X = df['skills'].str.lower()
y = df['career']

# TF-IDF Vectorizer (better weighting)
vectorizer = TfidfVectorizer()
X_vec = vectorizer.fit_transform(X)

model = MultinomialNB()
model.fit(X_vec, y)

# -----------------------------
# Step 3: Streamlit UI & Styling
# -----------------------------

# Custom CSS for a beautiful, modern UI
st.markdown("""
<style>
    /* Animated Background */
    .stApp {
        background: linear-gradient(-45deg, #0f172a, #1e293b, #0f172a, #334155);
        background-size: 400% 400%;
        animation: gradientBG 15s ease infinite;
        color: white;
    }
    @keyframes gradientBG {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }
    
    /* Glassmorphism Elements */
    .glass-card {
        background: rgba(255, 255, 255, 0.05);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        border-radius: 15px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        padding: 25px;
        margin-bottom: 20px;
        box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.3);
    }
    
    /* Typography improvements */
    h1, h2, h3 {
        font-family: 'Inter', sans-serif;
        color: #e2e8f0;
    }
    .main-title {
        text-align: center;
        font-size: 3em;
        font-weight: 800;
        background: -webkit-linear-gradient(45deg, #38bdf8, #818cf8);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 0.2em;
    }
    .subtitle {
        text-align: center;
        color: #94a3b8;
        font-size: 1.2em;
        margin-bottom: 2em;
    }
    
    /* Customizing text input labels */
    .stTextInput label {
        color: #e2e8f0 !important;
        font-weight: 600;
        font-size: 1.1em;
    }
    
    /* Customizing text input field */
    .stTextInput > div > div > input {
        border-radius: 10px;
        border: 1px solid #475569;
        background-color: rgba(15, 23, 42, 0.6);
        color: white;
        padding: 15px;
    }
    .stTextInput > div > div > input:focus {
        border-color: #38bdf8;
        box-shadow: 0 0 0 1px #38bdf8;
    }
    
    /* Custom button */
    .stButton > button {
        width: 100%;
        border-radius: 10px;
        background: linear-gradient(90deg, #38bdf8 0%, #818cf8 100%);
        color: white;
        font-weight: bold;
        border: none;
        padding: 0.6rem 1rem;
        transition: all 0.3s ease;
    }
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(56, 189, 248, 0.4);
        color: white;
        border: none;
    }
</style>
""", unsafe_allow_html=True)

st.markdown('<h1 class="main-title">AI Career Navigator</h1>', unsafe_allow_html=True)
st.markdown('<p class="subtitle">Discover your optimal career path based on your unique skill set.</p>', unsafe_allow_html=True)

col1, col2, col3 = st.columns([1, 8, 1])

with col2:
    st.markdown('<div class="glass-card">', unsafe_allow_html=True)
    skills_input = st.text_input("✨ What are your skills?", placeholder="e.g., python sql machine-learning aws")
    
    st.markdown('<br>', unsafe_allow_html=True)
    submit_button = st.button("Predict My Career Path 🚀")
    st.markdown('</div>', unsafe_allow_html=True)

if submit_button:
    if skills_input.strip() == "":
        col2.error("⚠️ Please enter at least one skill to get a prediction.")
    else:
        with st.spinner('Analyzing your skill profile...'):
            user_vec = vectorizer.transform([skills_input.lower()])

            # Get probabilities
            probs = model.predict_proba(user_vec)[0]
            classes = model.classes_

            # Combine & sort
            results = list(zip(classes, probs))
            results = sorted(results, key=lambda x: x[1], reverse=True)

            st.markdown("<br>", unsafe_allow_html=True)
            st.markdown("<h2 style='text-align: center;'>🎯 Your Top Career Matches</h2><br>", unsafe_allow_html=True)

            # Best Match highlight
            best_match, best_prob = results[0]
            st.success(f"🏆 **Top Recommendation: {best_match}** ({round(best_prob * 100, 1)}% Match)")

            # Layout for results
            res_col1, res_col2 = st.columns([1, 1])
            
            # Show Top 3 predictions with progress bars in glass styling
            for i in range(3):
                career, prob = results[i]
                confidence = prob * 100
                st.markdown(f"""
                <div style="background: rgba(255, 255, 255, 0.05); padding: 15px; border-radius: 10px; margin-bottom: 10px; border-left: 4px solid {'#38bdf8' if i==0 else '#4f46e5'};">
                    <h4 style="margin: 0; padding: 0; color: #e2e8f0;">{career}</h4>
                    <p style="margin: 5px 0 10px 0; color: #94a3b8; font-size: 0.9em;">Match Confidence: {round(confidence, 1)}%</p>
                </div>
                """, unsafe_allow_html=True)
                st.progress(float(prob))
                st.markdown("<br>", unsafe_allow_html=True)

# -----------------------------
# Extra Feature Footer
# -----------------------------
st.markdown("<br><hr style='border-color: #334155;'>", unsafe_allow_html=True)
st.markdown("<p style='text-align: center; color: #64748b;'>💡 Try experimenting with varied skills like: <em>python, react, docker, aws, figma</em></p>", unsafe_allow_html=True)
