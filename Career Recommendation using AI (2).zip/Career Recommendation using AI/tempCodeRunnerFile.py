import pandas as pd
import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
import random
import matplotlib.pyplot as plt

# -----------------------------
# STEP 1: DATASET
# -----------------------------

skills_list = [
    "python","java","c++","html","css","javascript","react","nodejs","sql",
    "machine learning","ai","deep learning","data analysis","cloud","aws",
    "cybersecurity","networking","docker","kubernetes",
    "accounting","finance","taxation","economics","business","marketing",
    "sales","management","investment","banking","excel","tally",
    "writing","history","politics","sociology","psychology","teaching",
    "public speaking","journalism","design","creativity"
]

career_data = [
    ("python ai machine learning", "AI Engineer", "Science", "Postgraduate"),
    ("java c++ software development", "Software Engineer", "Science", "Undergraduate"),
    ("html css javascript react", "Frontend Developer", "Science", "Undergraduate"),
    ("cloud aws docker kubernetes", "Cloud Engineer", "Science", "Postgraduate"),
    ("cybersecurity networking", "Cybersecurity Analyst", "Science", "Undergraduate"),

    ("accounting finance taxation", "Chartered Accountant", "Commerce", "Postgraduate"),
    ("business marketing sales", "Marketing Manager", "Commerce", "Undergraduate"),
    ("economics finance investment", "Financial Analyst", "Commerce", "Postgraduate"),
    ("banking finance", "Bank Officer", "Commerce", "Undergraduate"),

    ("writing journalism content", "Journalist", "Arts", "Undergraduate"),
    ("psychology counseling", "Psychologist", "Arts", "Postgraduate"),
    ("history politics sociology", "Civil Services", "Arts", "Postgraduate"),
    ("teaching communication", "Teacher", "Arts", "Undergraduate"),
    ("design creativity", "Graphic Designer", "Arts", "Diploma"),
]

dataset = []
for _ in range(2000):
    base = random.choice(career_data)
    skills = base[0].split()
    extra = random.sample(skills_list, random.randint(1, 3))
    all_skills = list(set(skills + extra))

    dataset.append({
        "skills": " ".join(all_skills),
        "career": base[1],
        "stream": base[2],
        "level": base[3]
    })

df = pd.DataFrame(dataset)

# -----------------------------
# STEP 2: MODEL
# -----------------------------

X = df['skills'].str.lower()
y = df['career']

vectorizer = TfidfVectorizer()
X_vec = vectorizer.fit_transform(X)

model = MultinomialNB()
model.fit(X_vec, y)

# -----------------------------
# EXTRA DATA
# -----------------------------

career_roadmap = {
    "Software Engineer": ["DSA", "Projects", "System Design"],
    "AI Engineer": ["Deep Learning", "TensorFlow", "Projects"],
    "Cloud Engineer": ["AWS", "Docker", "Kubernetes"],
    "Cybersecurity Analyst": ["Networking", "Ethical Hacking"],
    "Chartered Accountant": ["Accounting", "Taxation"],
    "Marketing Manager": ["SEO", "Digital Marketing"],
    "Journalist": ["Writing", "Communication"],
    "Psychologist": ["Counseling", "Internships"]
}

career_skills_map = {
    "Software Engineer": ["python","java","c++"],
    "AI Engineer": ["python","ai","ml"],
    "Cloud Engineer": ["aws","docker"],
    "Cybersecurity Analyst": ["networking"],
}

career_info = {
    "Software Engineer": "Builds applications and systems",
    "AI Engineer": "Creates intelligent AI systems",
    "Cloud Engineer": "Manages cloud infrastructure",
    "Marketing Manager": "Handles branding and promotion"
}

# -----------------------------
# UI
# -----------------------------

st.title("🚀 AI Career Recommendation System (PRO)")

stream_input = st.selectbox("Select Stream", ["Any","Science","Commerce","Arts"])
level_input = st.selectbox("Select Level", ["Any","Undergraduate","Postgraduate","Diploma"])

skills_input = st.text_input("Enter your skills")

# Resume Upload
uploaded_file = st.file_uploader("Upload Resume (txt only)")

# -----------------------------
# PREDICTION
# -----------------------------

if st.button("Predict Career"):

    if uploaded_file:
        text = uploaded_file.read().decode("utf-8")
        input_text = text.lower()
    else:
        input_text = skills_input.lower()

    if input_text.strip() == "":
        st.warning("Enter skills or upload resume")
    else:
        user_vec = vectorizer.transform([input_text])
        probs = model.predict_proba(user_vec)[0]
        classes = model.classes_

        results = list(zip(classes, probs))
        results = sorted(results, key=lambda x: x[1], reverse=True)

        st.subheader("🎯 Top Careers")

        count = 0
        for career, prob in results:
            row = df[df['career'] == career].iloc[0]

            if (stream_input == "Any" or row['stream'] == stream_input) and \
               (level_input == "Any" or row['level'] == level_input):

                st.write(f"**{career}** → {round(prob*100,2)}%")
                count += 1

            if count == 3:
                break

        best_career = results[0][0]
        st.success(f"🏆 Best Match: {best_career}")

        # -----------------------------
        # ROADMAP
        # -----------------------------
        st.subheader("📈 Career Roadmap")
        if best_career in career_roadmap:
            for step in career_roadmap[best_career]:
                st.write("➡️", step)

        # -----------------------------
        # SKILL GAP
        # -----------------------------
        st.subheader("🧠 Skill Gap")
        user_skills = input_text.split()

        if best_career in career_skills_map:
            required = career_skills_map[best_career]
            missing = [s for s in required if s not in user_skills]

            if missing:
                st.write("❌ Missing:", ", ".join(missing))
            else:
                st.write("✅ You are ready!")

        # -----------------------------
        # CAREER INFO
        # -----------------------------
        st.subheader("📘 About Career")
        if best_career in career_info:
            st.write(career_info[best_career])

        # -----------------------------
        # GRAPH
        # -----------------------------
        st.subheader("📊 Confidence Chart")

        top3 = results[:3]
        names = [i[0] for i in top3]
        values = [i[1] for i in top3]

        fig, ax = plt.subplots()
        ax.barh(names, values)
        st.pyplot(fig)

        # -----------------------------
        # SAVE HISTORY
        # -----------------------------
        history = pd.DataFrame({
            "input": [input_text],
            "prediction": [best_career]
        })

        history.to_csv("history.csv", mode='a', header=False, index=False)

# -----------------------------
# FOOTER
# -----------------------------

st.write("💡 Try: python ai, accounting finance, writing journalism")